﻿
var AngularJsTestController = function ($scope) {
    var _self = this;

    _self.description = "AngularJS test view for UmbracoAngularFrontend";
};